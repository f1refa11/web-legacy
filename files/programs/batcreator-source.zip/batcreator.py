from tkinter import *
from tkinter import scrolledtext
from tkinter import filedialog as fd

def muteBt():
	codeField.insert(END, "@echo off\n")

def printBt():
	codeField.insert(END, "echo Hello!\n")

def startBt():
	codeField.insert(END, "start explorer.exe\n")

def mdBt():
	codeField.insert(END, "md Folder\n")

def rdBt():
	codeField.insert(END, "rd Folder\n")

def msgBt():
	codeField.insert(END, "msg * hello\n")

def funcLoopBt():
	codeField.insert(END, ":loop\n")

def callFuncBt():
	codeField.insert(END, "goto loop\n")

def saveFile():
	fileName = fd.asksaveasfilename(filetypes=(("Bat Files", "*.bat"),
												("Cmd Files", "*.cmd"),
												("All files", "*.*") ), defaultextension='')

	code = codeField.get(1.0, END)
	file = open(fileName, "w")
	file.write(code)
	file.close()

root = Tk()
root.title("BatCreator by FireFall v.1.0")
root.geometry("600x350")
root.resizable(False, False)

muteButton = Button(text="Mute", width=12, command=muteBt)
muteButton.grid(row=0, column=0, pady=7, padx=10)

printButton = Button(text="Print", width=12, command=printBt)
printButton.grid(row=1, column=0, pady=7, padx=10)

startButton = Button(text="Start", width=12, command=startBt)
startButton.grid(row=2, column=0, pady=7, padx=10)

createFolderButton = Button(text="Create Folder", width=12, command=mdBt)
createFolderButton.grid(row=3, column=0, pady=7, padx=10)

deleteFolderButton = Button(text="Delete Folder", width=12, command=rdBt)
deleteFolderButton.grid(row=4, column=0, pady=7, padx=10)

messageBoxButton = Button(text="Message Box", width=12, command=msgBt)
messageBoxButton.grid(row=5, column=0, pady=7, padx=10)

loopFunctionButton = Button(text="Loop Function", width=12, command=funcLoopBt)
loopFunctionButton.grid(row=6, column=0, pady=7, padx=10)

loopFunctionButton = Button(text="Call Function", width=12, command=callFuncBt)
loopFunctionButton.grid(row=7, column=0, pady=7, padx=10)

saveButton = Button(text="Save", width=12, command=saveFile)
saveButton.grid(row=0, column=1, pady=7, padx=10)

codeField = scrolledtext.ScrolledText(width=33, height=21)
codeField.place(x=314, y=0)

root.mainloop()