# PYGENERATOR BY FIREFALL
# VERSION CONSOLE 0.6

import random
import time
import webbrowser

# commands
com1 = "help"
com2 = "options"
com2_1 = "options edit"
com3 = "exit"
com4 = "gen"
com5 = "about"
com6 = "sel_lang"

# data for generation
key = ''
number_symbols = 5
type_numbers = False
type_letters = False
type_both = True

def analyse_type():
	if type_numbers == True:
		print("Type of generator:", "Only Numbers")
	elif type_numbers == False:
		if type_letters == True:
			print("Type of generator:", "Only Letters")
		elif type_letters == False:
			if type_both == True:
				print("Type of generator:", "Numbers and Letters")

def generate():
	global key
	key = ''
	for x in range(number_symbols):
		if type_numbers == True:
			key = key + random.choice(list('123456789'))
		elif type_numbers == False:
			if type_letters == True:
				key = key + random.choice(list('qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM'))
			elif type_letters == False:
				if type_both == True:
					key = key + random.choice(list('123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM'))
				else:
					print("Error 2: Can't analyse the type of generation")

cycle = True
print("Welcome to PyGenerator v.0.6 console!")
print("Type 'help' to more information")
while cycle == True:
	command_input = input("| ")
	if command_input == com1:
		print("options - see the info of generator")
		print("options edit - manage generator")
		print("exit - exit the program")
		print("gen - generate a key")
		print("sel_lang - select your language")
		print("about - learn about the PyGenerator project")
	elif command_input == com2:
		print("Type 'options_edit' to edit generation options")
		print("")
		print("Generation options:\nThe number of characters in the key:", number_symbols)
		analyse_type()
	elif command_input == com2_1:
		number_symbols = int(input("Enter the number of characters in the key: "))
		gen_options_type = input("Enter the type of generator(n - only numbers, l - only letters, b - both): ")
		if gen_options_type == "n":
			type_numbers = True
			type_letters = False
			type_both = False
		elif gen_options_type == "l":
			type_numbers = False
			type_letters = True
			type_both = False
		elif gen_options_type == "b":
			type_numbers = False
			type_letters = False
			type_both = True
		else:
			print("Error 2: This is no type. To try again, type 'options edit' again")
		print("Generator has been successfully changed!")
	elif command_input == com3:
		exit()
	elif command_input == com4:
		time.sleep(random.randint(2,5))
		generate()
		print("The key is:", key)
		save = input("Do you want to save the key? Y or N? ")
		if save == "Y":
			handle = open("pygenerator_key.txt", "w")
			handle.write(key)
			handle.close()
		if save == "y":
			handle = open("pygenerator_key.txt", "w")
			handle.write(key)
			handle.close()
	elif command_input == com5:
		print("PyGenerator v1 by FireFall")
		print("Site: firefallsite.000webhostapp.com/")